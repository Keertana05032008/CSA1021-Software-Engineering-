import { useState, type FormEvent, type ReactNode } from "react";

type Screen = "home" | "results" | "seats" | "passenger" | "payment" | "confirmation";
type IconName =
  | "arrow"
  | "bus"
  | "calendar"
  | "card"
  | "cash"
  | "check"
  | "chevron"
  | "clock"
  | "location"
  | "phone"
  | "route"
  | "seat"
  | "shield"
  | "sparkle"
  | "swap"
  | "user";

const steps = [
  { id: "results", label: "Choose bus", icon: "bus" },
  { id: "seats", label: "Select seats", icon: "seat" },
  { id: "passenger", label: "Your details", icon: "user" },
  { id: "payment", label: "Payment", icon: "card" },
] as const;

const buses = [
  {
    name: "GreenLine Express",
    type: "AC Sleeper",
    departure: "07:30 AM",
    arrival: "02:00 PM",
    duration: "6h 30m",
    price: 850,
    rating: "4.8",
    seats: 12,
  },
  {
    name: "Kaveri Travels",
    type: "AC Seater",
    departure: "09:15 AM",
    arrival: "04:30 PM",
    duration: "7h 15m",
    price: 720,
    rating: "4.6",
    seats: 18,
  },
  {
    name: "CityLink Premium",
    type: "Volvo Multi-Axle",
    departure: "10:00 PM",
    arrival: "04:45 AM",
    duration: "6h 45m",
    price: 980,
    rating: "4.9",
    seats: 8,
  },
  {
    name: "Southern Star",
    type: "Non-AC Seater",
    departure: "11:30 PM",
    arrival: "06:30 AM",
    duration: "7h 00m",
    price: 590,
    rating: "4.5",
    seats: 21,
  },
];

const bookedSeats = ["A2", "B3", "C1", "D4", "E2", "F3"];
const seatRows = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M"];
const totalBookingAmount = 1700;

function getTomorrow() {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  return tomorrow.toISOString().split("T")[0];
}

function formatJourneyDate(value: string) {
  if (!value) return "Select date";
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${value}T00:00:00Z`));
}

function cityCode(city: string) {
  return city.trim().slice(0, 3).toUpperCase() || "---";
}

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></>,
    bus: <><path d="M6 17h12" /><path d="M6 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" /><path d="M18 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z" /><path d="M4 17V6a3 3 0 0 1 3-3h10a3 3 0 0 1 3 3v11" /><path d="M4 9h16M8 3v6m8-6v6" /></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M16 3v4M8 3v4M3 10h18" /></>,
    card: <><rect x="3" y="5" width="18" height="14" rx="3" /><path d="M3 10h18M7 15h3" /></>,
    cash: <><rect x="3" y="6" width="18" height="13" rx="2" /><path d="M7 10a3 3 0 0 1-3 3m13-3a3 3 0 0 0 3 3m-13 2a3 3 0 0 0-3-3m13 3a3 3 0 0 1 3-3" /><circle cx="12" cy="12.5" r="2.5" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    location: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    phone: <><rect x="6" y="2" width="12" height="20" rx="3" /><path d="M10 18h4" /></>,
    route: <><circle cx="6" cy="18" r="2" /><circle cx="18" cy="6" r="2" /><path d="M8 18h3a2 2 0 0 0 2-2V8a2 2 0 0 1 2-2h1" /></>,
    seat: <><path d="M6 12V5a2 2 0 0 1 4 0v7M6 9H5a2 2 0 0 0-2 2v5h18v-5a2 2 0 0 0-2-2h-1" /><path d="M14 12V5a2 2 0 0 1 4 0v7M5 16v4m14-4v4" /></>,
    shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
    sparkle: <><path d="m12 3 1.2 3.8L17 8l-3.8 1.2L12 13l-1.2-3.8L7 8l3.8-1.2L12 3Z" /><path d="m18 14 .8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8L18 14Z" /></>,
    swap: <><path d="m7 7 3-3m-3 3 3 3M7 7h10" /><path d="m17 17-3 3m3-3-3-3m3 3H7" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  };

  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name]}
    </svg>
  );
}

function Field({
  label,
  icon,
  children,
}: {
  label: string;
  icon: IconName;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      <span className="field-control">
        <Icon name={icon} size={19} />
        {children}
      </span>
    </label>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [selectedBus, setSelectedBus] = useState(buses[0]);
  const [selectedSeat, setSelectedSeat] = useState("B2");
  const [payment, setPayment] = useState("Credit / Debit Card");
  const [passengerName, setPassengerName] = useState("");
  const [from, setFrom] = useState("Chennai");
  const [to, setTo] = useState("Bangalore");
  const [date, setDate] = useState(getTomorrow);

  const screenIndex = ["home", "results", "seats", "passenger", "payment", "confirmation"].indexOf(screen);

  function selectBus(bus: typeof buses[0]) {
    setSelectedBus(bus);
    setScreen("seats");
  }

  function submitPassenger(event: FormEvent) {
    event.preventDefault();
    setScreen("payment");
  }

  function swapCities() {
    setFrom(to);
    setTo(from);
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand" onClick={() => setScreen("home")} aria-label="Go to home">
          <span className="brand-mark"><Icon name="bus" size={23} /></span>
          <span>BusGo</span>
        </button>

        <div className="sidebar-copy">
          <span className="eyebrow light"><Icon name="sparkle" size={15} /> Quick & simple</span>
          <h2>Your journey,<br />made easier.</h2>
          <p>Book your bus ticket in just a few simple steps.</p>
        </div>

        <nav className="steps" aria-label="Booking progress">
          {steps.map((step, index) => {
            const activeIndex = Math.max(0, screenIndex - 1);
            const isDone = screenIndex > index + 1;
            const isActive = screen !== "home" && index === activeIndex;
            return (
              <div className={`step ${isActive ? "active" : ""} ${isDone ? "done" : ""}`} key={step.id}>
                <span className="step-icon">
                  {isDone ? <Icon name="check" size={17} /> : <Icon name={step.icon} size={18} />}
                </span>
                <span>
                  <small>Step {index + 1}</small>
                  <strong>{step.label}</strong>
                </span>
              </div>
            );
          })}
        </nav>

        <div className="support-note">
          <Icon name="shield" size={22} />
          <span><strong>Safe booking</strong><small>Your payment is protected</small></span>
        </div>
      </aside>

      <main className="main-content">
        {screen === "home" && (
          <section className="home-screen screen">
            <div className="home-heading">
              <span className="eyebrow"><Icon name="sparkle" size={15} /> Let’s plan your trip</span>
              <h1>Where would you like to go?</h1>
              <p>Search and book comfortable bus journeys across the city.</p>
            </div>

            <div className="search-card">
              <div className="route-fields">
                <Field label="From" icon="location">
                  <input value={from} onChange={(event) => setFrom(event.target.value)} aria-label="Departure city" />
                </Field>
                <button className="swap-button" type="button" aria-label="Swap cities" onClick={swapCities}><Icon name="swap" size={19} /></button>
                <Field label="To" icon="location">
                  <input value={to} onChange={(event) => setTo(event.target.value)} aria-label="Arrival city" />
                </Field>
              </div>
              <Field label="Journey date" icon="calendar">
                <input type="date" value={date} onChange={(event) => setDate(event.target.value)} aria-label="Journey date" />
              </Field>
              <button className="primary-button" onClick={() => setScreen("results")}>
                Search buses <Icon name="arrow" size={19} />
              </button>
            </div>

            <div className="feature-row">
              <div><span><Icon name="route" /></span><strong>100+ routes</strong><small>Across major cities</small></div>
              <div><span><Icon name="seat" /></span><strong>Easy selection</strong><small>Pick your favorite seat</small></div>
              <div><span><Icon name="shield" /></span><strong>Secure payment</strong><small>Simple and protected</small></div>
            </div>
          </section>
        )}

        {screen === "results" && (
          <section className="screen">
            <ScreenHeader
              eyebrow="Available buses"
              title="Choose your bus"
              description="4 buses available for your journey"
              onBack={() => setScreen("home")}
            />
            <div className="journey-strip">
              <div><small>From</small><strong>{from || "From city"}</strong></div>
              <span className="route-line"><i /><Icon name="bus" size={21} /><i /></span>
              <div><small>To</small><strong>{to || "To city"}</strong></div>
              <span className="date-chip"><Icon name="calendar" size={17} /> {formatJourneyDate(date)}</span>
            </div>
            <div className="bus-list">
              {buses.map((bus) => (
                <article className="bus-card" key={bus.name}>
                  <div className="bus-mark"><Icon name="bus" size={25} /></div>
                  <div className="bus-info">
                    <span className="bus-title"><h3>{bus.name}</h3><em>★ {bus.rating}</em></span>
                    <p>{bus.type} · {bus.seats} seats left</p>
                  </div>
                  <div className="bus-time">
                    <strong>{bus.departure}</strong>
                    <span><i /><small>{bus.duration}</small><i /></span>
                    <strong>{bus.arrival}</strong>
                  </div>
                  <div className="bus-price">
                    <small>From</small>
                    <strong>₹{bus.price}</strong>
                  </div>
                  <button className="select-button" onClick={() => selectBus(bus)}>
                    Select <Icon name="chevron" size={17} />
                  </button>
                </article>
              ))}
            </div>
          </section>
        )}

        {screen === "seats" && (
          <section className="screen">
            <ScreenHeader eyebrow="Seat selection" title="Pick your seat" description={`${selectedBus.name} · ${selectedBus.type}`} onBack={() => setScreen("results")} />
            <div className="two-column">
              <div className="seat-panel card">
                <div className="seat-legend">
                  <span><i className="seat-sample available" />Available</span>
                  <span><i className="seat-sample selected" />Selected</span>
                  <span><i className="seat-sample booked" />Booked</span>
                  <strong>52-seat coach</strong>
                </div>
                <div className="bus-layout">
                  <div className="bus-front">
                    <span className="windshield">Front</span>
                    <span className="entry">Entry</span>
                    <span className="driver"><small>Driver</small><b>◯</b></span>
                  </div>
                  <div className="seat-grid">
                    {seatRows.map((row, rowIndex) => (
                      <div className="seat-row" key={row}>
                        <span className="row-number">{rowIndex + 1}</span>
                        {[1, 2, 3, 4].map((number) => {
                        const seat = `${row}${number}`;
                        const booked = bookedSeats.includes(seat);
                        return (
                          <button
                            key={seat}
                            className={`seat ${booked ? "booked" : ""} ${selectedSeat === seat ? "selected" : ""} ${number === 3 ? "aisle" : ""}`}
                            disabled={booked}
                            onClick={() => setSelectedSeat(seat)}
                            aria-label={`Seat ${seat}${booked ? ", booked" : ""}`}
                          >
                            {seat}
                          </button>
                        );
                        })}
                      </div>
                    ))}
                  </div>
                  <div className="bus-rear"><span>Rear</span></div>
                </div>
              </div>
              <aside className="summary-card card">
                <h3>Trip summary</h3>
                <div className="mini-route"><span>{cityCode(from)}<small>07:30 AM</small></span><i /><Icon name="bus" size={18} /><i /><span>{cityCode(to)}<small>02:00 PM</small></span></div>
                <div className="summary-line"><span>Journey date</span><strong>{formatJourneyDate(date)}</strong></div>
                <div className="summary-line"><span>Selected seat</span><strong className="seat-badge">{selectedSeat}</strong></div>
                <div className="total-line"><span>Total amount</span><strong>₹{selectedBus.price}</strong></div>
                <button className="primary-button full" onClick={() => setScreen("passenger")}>Continue <Icon name="arrow" size={18} /></button>
              </aside>
            </div>
          </section>
        )}

        {screen === "passenger" && (
          <section className="screen narrow-screen">
            <ScreenHeader eyebrow="Passenger details" title="Tell us about you" description="Enter the details of the passenger travelling" onBack={() => setScreen("seats")} />
            <form className="form-card card" onSubmit={submitPassenger}>
              <div className="form-title"><span><Icon name="user" /></span><div><h3>Passenger 1</h3><p>Seat {selectedSeat} · Adult</p></div></div>
              <div className="form-grid">
                <Field label="Full name" icon="user"><input required placeholder="Enter passenger name" value={passengerName} onChange={(e) => setPassengerName(e.target.value)} /></Field>
                <Field label="Age" icon="calendar"><input required type="number" min="1" placeholder="Enter age" /></Field>
                <label className="field">
                  <span className="field-label">Gender</span>
                  <span className="gender-options">
                    {["Male", "Female", "Other"].map((gender, index) => (
                      <span key={gender}><input type="radio" name="gender" defaultChecked={index === 0} />{gender}</span>
                    ))}
                  </span>
                </label>
                <Field label="Phone number" icon="phone"><input required type="tel" placeholder="+91 98765 43210" /></Field>
              </div>
              <div className="form-footer">
                <p><Icon name="shield" size={18} />Your details are securely stored</p>
                <button className="primary-button" type="submit">Proceed to payment <Icon name="arrow" size={18} /></button>
              </div>
            </form>
          </section>
        )}

        {screen === "payment" && (
          <section className="screen narrow-screen">
            <ScreenHeader eyebrow="Secure payment" title="Complete your payment" description="Choose your preferred payment method" onBack={() => setScreen("passenger")} />
            <div className="payment-grid">
              <div className="payment-card card">
                <h3>Payment method</h3>
                <div className="payment-options">
                  {[
                    { name: "UPI", note: "Google Pay, PhonePe, Paytm", icon: "phone" as IconName },
                    { name: "Credit / Debit Card", note: "Visa, Mastercard and RuPay", icon: "card" as IconName },
                    { name: "Cash", note: "Pay at boarding point", icon: "cash" as IconName },
                  ].map((option) => (
                    <button className={`payment-option ${payment === option.name ? "selected" : ""}`} onClick={() => setPayment(option.name)} key={option.name}>
                      <span><Icon name={option.icon} /></span>
                      <span><strong>{option.name}</strong><small>{option.note}</small></span>
                      <i>{payment === option.name && <Icon name="check" size={15} />}</i>
                    </button>
                  ))}
                </div>
                {payment === "Credit / Debit Card" && (
                  <div className="card-fields">
                    <Field label="Cardholder name" icon="user">
                      <input aria-label="Cardholder name" placeholder="Keertana K" autoComplete="cc-name" />
                    </Field>
                    <Field label="Card number" icon="card">
                      <input aria-label="Card number" placeholder="4111 1111 1111 1111" inputMode="numeric" autoComplete="cc-number" maxLength={19} />
                    </Field>
                    <div className="card-field-row">
                      <Field label="Expiry date (MM/YY)" icon="calendar">
                        <input aria-label="Expiry date" placeholder="12/30" inputMode="numeric" autoComplete="cc-exp" maxLength={5} />
                      </Field>
                      <Field label="CVV" icon="shield">
                        <input aria-label="CVV" placeholder="123" inputMode="numeric" autoComplete="cc-csc" maxLength={3} type="password" />
                      </Field>
                    </div>
                  </div>
                )}
              </div>
              <aside className="fare-card card">
                <h3>Fare summary</h3>
                <div><span>Ticket fare</span><strong>₹{totalBookingAmount.toLocaleString("en-IN")}</strong></div>
                <div><span>Booking fee</span><strong>₹0</strong></div>
                <div className="fare-total"><span>Total booking amount</span><strong>₹{totalBookingAmount.toLocaleString("en-IN")}</strong></div>
                <button className="primary-button full pay-now-button" onClick={() => setScreen("confirmation")}>Pay Now · ₹{totalBookingAmount.toLocaleString("en-IN")} <Icon name="arrow" size={18} /></button>
                <p><Icon name="shield" size={16} />100% secure payment</p>
              </aside>
            </div>
          </section>
        )}

        {screen === "confirmation" && (
          <section className="screen confirmation-screen">
            <div className="success-mark"><span><Icon name="check" size={34} /></span></div>
            <span className="eyebrow">Payment successful</span>
            <h1>Booking confirmed!</h1>
            <p>Your ticket is ready. Have a safe and happy journey.</p>
            <div className="ticket-card">
              <div className="ticket-top">
                <span className="brand-mark"><Icon name="bus" size={21} /></span>
                <div><small>Bus ticket</small><strong>{selectedBus.name}</strong></div>
                <span className="confirmed-chip"><Icon name="check" size={14} /> Confirmed</span>
              </div>
              <div className="ticket-route">
                <div><strong>{from || "From city"}</strong><small>07:30 AM</small></div>
                <span><i /><Icon name="bus" size={20} /><i /></span>
                <div><strong>{to || "To city"}</strong><small>02:00 PM</small></div>
              </div>
              <div className="ticket-details">
                <span><small>Booking ID</small><strong>BG482910</strong></span>
                <span><small>Journey date</small><strong>{formatJourneyDate(date)}</strong></span>
                <span><small>Seat number</small><strong>{selectedSeat}</strong></span>
                <span><small>Total amount</small><strong>₹{totalBookingAmount.toLocaleString("en-IN")}</strong></span>
              </div>
              <div className="ticket-passenger"><Icon name="user" size={18} /><span><small>Passenger</small><strong>{passengerName || "Arun Kumar"}</strong></span></div>
            </div>
            <button className="primary-button home-button" onClick={() => setScreen("home")}>Back to home <Icon name="arrow" size={18} /></button>
          </section>
        )}
      </main>
    </div>
  );
}

function ScreenHeader({
  eyebrow,
  title,
  description,
  onBack,
}: {
  eyebrow: string;
  title: string;
  description: string;
  onBack: () => void;
}) {
  return (
    <header className="screen-header">
      <button className="back-button" onClick={onBack} aria-label="Go back"><Icon name="arrow" size={19} /></button>
      <div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>
    </header>
  );
}
