import { useMemo, useState } from "react";

type Screen =
  | "welcome"
  | "homeA"
  | "homeB"
  | "categories"
  | "listing"
  | "details"
  | "wishlist"
  | "cart"
  | "checkout"
  | "payment"
  | "confirmation"
  | "review"
  | "feedback"
  | "summary"
  | "approval";

type IconName =
  | "arrow"
  | "bag"
  | "bell"
  | "card"
  | "cart"
  | "check"
  | "chevron"
  | "grid"
  | "heart"
  | "home"
  | "minus"
  | "plus"
  | "profile"
  | "search"
  | "shield"
  | "star"
  | "truck"
  | "wallet";

const photos = {
  hero: "https://images.unsplash.com/photo-1511556820780-d912e42b4980?auto=format&fit=crop&w=1200&q=85",
  shoe: "https://images.unsplash.com/photo-1529607225807-563e0851ee7e?auto=format&fit=crop&w=900&q=85",
  blackShoe: "https://images.unsplash.com/photo-1648818283312-0ef710ca1aae?auto=format&fit=crop&w=900&q=85",
  watch: "https://images.unsplash.com/photo-1568752172055-6961c4146efd?auto=format&fit=crop&w=900&q=85",
  tech: "https://images.unsplash.com/photo-1755645225935-1480e8ef4d05?auto=format&fit=crop&w=900&q=85",
  lifestyle: "https://images.unsplash.com/photo-1713929689473-572aeaa5ae12?auto=format&fit=crop&w=1200&q=85",
};

const products = [
  { id: 1, name: "CloudRun Sneakers", category: "Footwear", price: 89, oldPrice: 119, rating: 4.8, image: photos.shoe },
  { id: 2, name: "Core Smartwatch", category: "Electronics", price: 129, oldPrice: 159, rating: 4.6, image: photos.watch },
  { id: 3, name: "Studio Essentials", category: "Accessories", price: 74, oldPrice: 92, rating: 4.7, image: photos.tech },
  { id: 4, name: "Street Low Sneakers", category: "Footwear", price: 96, oldPrice: 130, rating: 4.5, image: photos.blackShoe },
];

const categoryItems = [
  { name: "Fashion", sub: "1,240 products", emoji: "01", image: photos.hero },
  { name: "Footwear", sub: "860 products", emoji: "02", image: photos.shoe },
  { name: "Electronics", sub: "540 products", emoji: "03", image: photos.tech },
  { name: "Accessories", sub: "420 products", emoji: "04", image: photos.watch },
];

function Icon({ name, size = 20, filled = false }: { name: IconName; size?: number; filled?: boolean }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: <path d="m15 18-6-6 6-6" />,
    bag: <><path d="M6 8h12l1 12H5L6 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" /><path d="M10 21h4" /></>,
    card: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18" /></>,
    cart: <><path d="M3 4h2l2 11h10l3-8H6" /><circle cx="9" cy="20" r="1" /><circle cx="17" cy="20" r="1" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
    heart: <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8Z" />,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v11h14V10M9 21v-7h6v7" /></>,
    minus: <path d="M5 12h14" />,
    plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
    profile: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    shield: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" /><path d="m9 12 2 2 4-4" /></>,
    star: <path d="m12 2 3 6 6.5 1-4.7 4.6 1.1 6.4-5.9-3.1L6.1 20l1.1-6.4L2.5 9 9 8l3-6Z" />,
    truck: <><path d="M3 6h11v11H3zM14 10h4l3 3v4h-7z" /><circle cx="7" cy="19" r="2" /><circle cx="18" cy="19" r="2" /></>,
    wallet: <><path d="M4 5h14a2 2 0 0 1 2 2v13H5a2 2 0 0 1-2-2V6a3 3 0 0 1 3-3h11" /><path d="M15 11h6v5h-6a2 2 0 0 1 0-5Z" /></>,
  };
  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function Button({
  children,
  onClick,
  variant = "primary",
  className = "",
  disabled = false,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "dark" | "soft" | "danger";
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button type="button" disabled={disabled} onClick={onClick} className={`btn btn-${variant} ${className}`}>
      {children}
    </button>
  );
}

function IconButton({
  icon,
  onClick,
  active = false,
  label,
}: {
  icon: IconName;
  onClick?: () => void;
  active?: boolean;
  label: string;
}) {
  return (
    <button type="button" aria-label={label} onClick={onClick} className={`icon-button ${active ? "active" : ""}`}>
      <Icon name={icon} filled={active} />
    </button>
  );
}

function Field({
  label,
  placeholder,
  type = "text",
  value,
  onChange,
}: {
  label?: string;
  placeholder: string;
  type?: string;
  value?: string;
  onChange?: (value: string) => void;
}) {
  return (
    <label className="field-wrap">
      {label && <span>{label}</span>}
      <input type={type} placeholder={placeholder} value={value} onChange={(e) => onChange?.(e.target.value)} />
    </label>
  );
}

function Header({
  title,
  onBack,
  right,
  eyebrow,
}: {
  title: string;
  onBack?: () => void;
  right?: React.ReactNode;
  eyebrow?: string;
}) {
  return (
    <header className="page-header">
      <div className="header-side">{onBack && <IconButton icon="arrow" onClick={onBack} label="Go back" />}</div>
      <div className="header-title">
        {eyebrow && <span>{eyebrow}</span>}
        <strong>{title}</strong>
      </div>
      <div className="header-side right">{right}</div>
    </header>
  );
}

function BottomNav({ active, go }: { active: string; go: (screen: Screen) => void }) {
  const items: { id: string; label: string; icon: IconName; screen: Screen }[] = [
    { id: "home", label: "Home", icon: "home", screen: "homeA" },
    { id: "categories", label: "Browse", icon: "grid", screen: "categories" },
    { id: "wishlist", label: "Wishlist", icon: "heart", screen: "wishlist" },
    { id: "cart", label: "Cart", icon: "bag", screen: "cart" },
    { id: "review", label: "Review", icon: "profile", screen: "review" },
  ];
  return (
    <nav className="bottom-nav">
      {items.map((item) => (
        <button key={item.id} type="button" className={active === item.id ? "active" : ""} onClick={() => go(item.screen)}>
          <span className="nav-icon">
            <Icon name={item.icon} filled={active === item.id} size={19} />
            {item.id === "cart" && <i>2</i>}
          </span>
          <small>{item.label}</small>
        </button>
      ))}
    </nav>
  );
}

function ProductCard({
  product,
  onOpen,
  liked,
  onLike,
  visual = false,
}: {
  product: (typeof products)[number];
  onOpen: () => void;
  liked: boolean;
  onLike: () => void;
  visual?: boolean;
}) {
  return (
    <article className={`product-card ${visual ? "visual" : ""}`}>
      <div className="product-image" onClick={onOpen}>
        <img src={product.image} alt={product.name} />
        <button aria-label="Save product" type="button" className={`heart-button ${liked ? "liked" : ""}`} onClick={(e) => { e.stopPropagation(); onLike(); }}>
          <Icon name="heart" size={17} filled={liked} />
        </button>
        {visual && <span className="discount">−25%</span>}
      </div>
      <button type="button" className="product-info" onClick={onOpen}>
        <small>{product.category}</small>
        <strong>{product.name}</strong>
        <div className="price-line">
          <b>${product.price}</b>
          <del>${product.oldPrice}</del>
          <span><Icon name="star" size={12} filled /> {product.rating}</span>
        </div>
      </button>
    </article>
  );
}

function SearchBar({ onClick }: { onClick: () => void }) {
  return (
    <button type="button" className="search-bar" onClick={onClick}>
      <Icon name="search" size={19} />
      <span>Search products and brands</span>
      <kbd>⌘ K</kbd>
    </button>
  );
}

function Welcome({ go }: { go: (s: Screen) => void }) {
  return (
    <main className="welcome-screen">
      <div className="welcome-visual">
        <img src={photos.lifestyle} alt="Curated everyday products" />
        <div className="welcome-logo"><span>S</span> ShopEase</div>
        <div className="floating-tag tag-one"><Icon name="shield" size={16} /> Secure checkout</div>
        <div className="floating-tag tag-two"><Icon name="truck" size={16} /> Free delivery</div>
      </div>
      <section className="welcome-content">
        <span className="eyebrow">A better way to shop</span>
        <div className="display-title">Find your everyday favorites.</div>
        <p>Curated quality, effortless checkout, and fast delivery—all in one simple app.</p>
        <div className="login-fields">
          <Field label="Email address" placeholder="you@example.com" type="email" />
          <Field label="Password" placeholder="Enter your password" type="password" />
        </div>
        <Button onClick={() => go("homeA")}>Sign in to ShopEase <span>→</span></Button>
        <button type="button" className="text-action" onClick={() => go("homeA")}>Continue as guest</button>
        <p className="terms">By continuing, you agree to our Terms and Privacy Policy.</p>
      </section>
    </main>
  );
}

function HomeA({
  go,
  wishlist,
  toggleLike,
}: {
  go: (s: Screen) => void;
  wishlist: number[];
  toggleLike: (id: number) => void;
}) {
  return (
    <main className="screen with-nav">
      <section className="home-top">
        <div>
          <span className="muted">Good morning,</span>
          <div className="brand-title">ShopEase<span>.</span></div>
        </div>
        <div className="top-actions"><IconButton icon="bell" label="Notifications" /><button type="button" className="avatar" onClick={() => go("review")}>AM</button></div>
      </section>
      <SearchBar onClick={() => go("listing")} />
      <section className="minimal-promo">
        <div>
          <span>SEASONAL EDIT</span>
          <div>Less noise.<br />Better choices.</div>
          <button type="button" onClick={() => go("listing")}>Shop collection <span>→</span></button>
        </div>
        <img src={photos.shoe} alt="White sneakers on sale" />
      </section>
      <SectionHeading title="Shop by category" action="View all" onClick={() => go("categories")} />
      <div className="category-pills">
        {["All", "Fashion", "Tech", "Home", "Beauty"].map((name, i) => (
          <button type="button" key={name} className={i === 0 ? "active" : ""} onClick={() => go("listing")}>{name}</button>
        ))}
      </div>
      <SectionHeading title="Featured for you" action="See all" onClick={() => go("listing")} />
      <div className="product-grid">
        {products.slice(0, 4).map((product) => (
          <ProductCard key={product.id} product={product} onOpen={() => go("details")} liked={wishlist.includes(product.id)} onLike={() => toggleLike(product.id)} />
        ))}
      </div>
      <BottomNav active="home" go={go} />
    </main>
  );
}

function SectionHeading({ title, action, onClick }: { title: string; action: string; onClick: () => void }) {
  return (
    <div className="section-heading">
      <strong>{title}</strong>
      <button type="button" onClick={onClick}>{action} <Icon name="chevron" size={14} /></button>
    </div>
  );
}

function HomeB({
  go,
  wishlist,
  toggleLike,
}: {
  go: (s: Screen) => void;
  wishlist: number[];
  toggleLike: (id: number) => void;
}) {
  return (
    <main className="screen visual-home with-nav">
      <section className="visual-header">
        <div className="brand-title light">ShopEase<span>.</span></div>
        <div className="top-actions"><IconButton icon="bell" label="Notifications" /><button type="button" className="avatar light" onClick={() => go("review")}>AM</button></div>
        <div className="visual-copy">
          <span>WEEKEND EXCLUSIVE</span>
          <div className="visual-title">Fresh looks.<br />Better prices.</div>
          <p>Up to 40% off this week’s most wanted styles.</p>
          <Button variant="secondary" onClick={() => go("listing")}>Explore the drop →</Button>
        </div>
      </section>
      <div className="visual-body">
        <SearchBar onClick={() => go("listing")} />
        <div className="visual-categories">
          {categoryItems.map((cat) => (
            <button type="button" key={cat.name} onClick={() => go("listing")}>
              <img src={cat.image} alt="" />
              <span>{cat.name}</span>
            </button>
          ))}
        </div>
        <section className="deal-card">
          <div><small>FLASH DEAL</small><strong>Buy 2, get 1 free</strong><span>Ends in 08 : 24 : 12</span></div>
          <img src={photos.tech} alt="Tech accessories offer" />
        </section>
        <SectionHeading title="Trending now" action="Shop all" onClick={() => go("listing")} />
        <div className="product-grid">
          {products.slice(0, 4).map((product) => (
            <ProductCard visual key={product.id} product={product} onOpen={() => go("details")} liked={wishlist.includes(product.id)} onLike={() => toggleLike(product.id)} />
          ))}
        </div>
      </div>
      <BottomNav active="home" go={go} />
    </main>
  );
}

function Categories({ go }: { go: (s: Screen) => void }) {
  return (
    <main className="screen with-nav">
      <Header title="Categories" right={<IconButton icon="search" label="Search" onClick={() => go("listing")} />} />
      <p className="intro-copy">Explore collections curated around how you live, work, and play.</p>
      <div className="category-list">
        {categoryItems.map((item) => (
          <button type="button" key={item.name} onClick={() => go("listing")}>
            <img src={item.image} alt="" />
            <span><small>{item.emoji}</small><strong>{item.name}</strong><em>{item.sub}</em></span>
            <i><Icon name="chevron" size={18} /></i>
          </button>
        ))}
      </div>
      <BottomNav active="categories" go={go} />
    </main>
  );
}

function Listing({
  go,
  wishlist,
  toggleLike,
}: {
  go: (s: Screen) => void;
  wishlist: number[];
  toggleLike: (id: number) => void;
}) {
  const [filter, setFilter] = useState("All");
  return (
    <main className="screen">
      <Header title="New arrivals" onBack={() => go("homeA")} right={<IconButton icon="cart" label="Cart" onClick={() => go("cart")} />} />
      <SearchBar onClick={() => undefined} />
      <div className="filter-row">
        {["All", "Shoes", "Tech", "Accessories"].map((item) => (
          <button type="button" key={item} onClick={() => setFilter(item)} className={filter === item ? "active" : ""}>{item}</button>
        ))}
      </div>
      <div className="results-line"><strong>48 products</strong><button type="button">Sort: Popular⌄</button></div>
      <div className="product-grid listing-grid">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} onOpen={() => go("details")} liked={wishlist.includes(product.id)} onLike={() => toggleLike(product.id)} />
        ))}
      </div>
    </main>
  );
}

function Details({
  go,
  liked,
  toggleLike,
}: {
  go: (s: Screen) => void;
  liked: boolean;
  toggleLike: () => void;
}) {
  const [size, setSize] = useState("8");
  const [added, setAdded] = useState(false);
  return (
    <main className="screen details-screen">
      <div className="details-image">
        <img src={photos.shoe} alt="CloudRun white sneakers" />
        <div className="details-controls"><IconButton icon="arrow" label="Back" onClick={() => go("listing")} /><div><IconButton icon="heart" label="Add to wishlist" active={liked} onClick={toggleLike} /><IconButton icon="cart" label="Cart" onClick={() => go("cart")} /></div></div>
        <span className="image-count">1 / 4</span>
      </div>
      <section className="details-content">
        <div className="product-kicker"><span>EVERYDAY ESSENTIALS</span><span><Icon name="star" size={13} filled /> 4.8 (246)</span></div>
        <div className="details-title">CloudRun Sneakers</div>
        <div className="details-price"><strong>$89.00</strong><del>$119.00</del><span>Save 25%</span></div>
        <p>Featherlight cushioning and breathable knit construction, designed for comfort from first step to last.</p>
        <div className="option-title"><strong>Select size</strong><button type="button">Size guide</button></div>
        <div className="sizes">{["6", "7", "8", "9", "10"].map((item) => <button type="button" key={item} onClick={() => setSize(item)} className={size === item ? "active" : ""}>{item}</button>)}</div>
        <div className="benefit-row"><span><Icon name="truck" /> Free delivery</span><span><Icon name="shield" /> 30-day returns</span></div>
        <Button className="add-button" onClick={() => { setAdded(true); setTimeout(() => go("cart"), 550); }}>
          {added ? <><Icon name="check" /> Added to bag</> : <>Add to bag <span>$89.00</span></>}
        </Button>
      </section>
    </main>
  );
}

function Wishlist({
  go,
  wishlist,
  toggleLike,
}: {
  go: (s: Screen) => void;
  wishlist: number[];
  toggleLike: (id: number) => void;
}) {
  const likedProducts = products.filter((p) => wishlist.includes(p.id));
  return (
    <main className="screen with-nav">
      <Header title="Wishlist" eyebrow={`${likedProducts.length} saved items`} right={<IconButton icon="cart" label="Cart" onClick={() => go("cart")} />} />
      {likedProducts.length ? (
        <div className="product-grid listing-grid">
          {likedProducts.map((product) => <ProductCard key={product.id} product={product} onOpen={() => go("details")} liked onLike={() => toggleLike(product.id)} />)}
        </div>
      ) : (
        <section className="empty-state"><span><Icon name="heart" size={30} /></span><strong>Your wishlist is waiting</strong><p>Save products you love and find them here.</p><Button onClick={() => go("listing")}>Explore products</Button></section>
      )}
      <BottomNav active="wishlist" go={go} />
    </main>
  );
}

function Quantity({ value, setValue }: { value: number; setValue: (n: number) => void }) {
  return (
    <div className="quantity">
      <button type="button" onClick={() => setValue(Math.max(1, value - 1))}><Icon name="minus" size={15} /></button>
      <span>{value}</span>
      <button type="button" onClick={() => setValue(value + 1)}><Icon name="plus" size={15} /></button>
    </div>
  );
}

function Cart({ go, quantity, setQuantity }: { go: (s: Screen) => void; quantity: number; setQuantity: (n: number) => void }) {
  const subtotal = quantity * 89 + 74;
  return (
    <main className="screen checkout-screen with-nav">
      <Header title="Your bag" eyebrow="2 items" onBack={() => go("homeA")} />
      <div className="cart-list">
        <div className="cart-item">
          <img src={photos.shoe} alt="CloudRun Sneakers" />
          <div><small>Footwear · Size 8</small><strong>CloudRun Sneakers</strong><span>$89.00</span><Quantity value={quantity} setValue={setQuantity} /></div>
          <button type="button" aria-label="Remove item">×</button>
        </div>
        <div className="cart-item">
          <img src={photos.tech} alt="Studio Essentials" />
          <div><small>Accessories · Black</small><strong>Studio Essentials</strong><span>$74.00</span><Quantity value={1} setValue={() => undefined} /></div>
          <button type="button" aria-label="Remove item">×</button>
        </div>
      </div>
      <button type="button" className="promo-row"><span>Have a promo code?</span><strong>Add code <Icon name="chevron" size={15} /></strong></button>
      <div className="order-total">
        <p><span>Subtotal</span><strong>${subtotal.toFixed(2)}</strong></p>
        <p><span>Delivery</span><strong className="success">Free</strong></p>
        <p className="grand-total"><span>Total</span><strong>${subtotal.toFixed(2)}</strong></p>
      </div>
      <div className="sticky-action">
        <Button onClick={() => go("checkout")}>Checkout · ${subtotal.toFixed(2)} <span>→</span></Button>
        <small><Icon name="shield" size={13} /> Secure encrypted checkout</small>
      </div>
      <BottomNav active="cart" go={go} />
    </main>
  );
}

function Checkout({ go }: { go: (s: Screen) => void }) {
  return (
    <main className="screen checkout-screen">
      <Header title="Checkout" eyebrow="Step 1 of 2" onBack={() => go("cart")} />
      <div className="progress"><span /><i /></div>
      <section className="form-section">
        <div className="form-heading"><span>1</span><div><strong>Delivery address</strong><small>Where should we send your order?</small></div></div>
        <Field label="Full name" placeholder="Alex Morgan" />
        <Field label="Street address" placeholder="24 Green Avenue" />
        <div className="field-grid"><Field label="City" placeholder="Brooklyn" /><Field label="ZIP code" placeholder="11201" /></div>
        <Field label="Phone number" placeholder="+1 212 555 0142" />
      </section>
      <section className="delivery-options">
        <strong>Delivery method</strong>
        <label className="radio-card active"><input type="radio" defaultChecked name="delivery" /><Icon name="truck" /><span><b>Standard delivery</b><small>2–4 business days</small></span><em>Free</em></label>
        <label className="radio-card"><input type="radio" name="delivery" /><Icon name="bag" /><span><b>Express delivery</b><small>Next business day</small></span><em>$12</em></label>
      </section>
      <div className="sticky-action plain"><Button onClick={() => go("payment")}>Continue to payment <span>→</span></Button></div>
    </main>
  );
}

function Payment({ go }: { go: (s: Screen) => void }) {
  const [method, setMethod] = useState("card");
  return (
    <main className="screen checkout-screen">
      <Header title="Payment" eyebrow="Step 2 of 2" onBack={() => go("checkout")} />
      <div className="progress complete"><span /><i /></div>
      <section className="payment-methods">
        <strong>Choose payment method</strong>
        <button type="button" className={method === "card" ? "active" : ""} onClick={() => setMethod("card")}><span><Icon name="card" /><b>Credit or debit card</b></span><i /></button>
        <button type="button" className={method === "wallet" ? "active" : ""} onClick={() => setMethod("wallet")}><span><Icon name="wallet" /><b>Digital wallet</b></span><i /></button>
      </section>
      {method === "card" && (
        <section className="form-section card-form">
          <Field label="Card number" placeholder="4242 4242 4242 4242" />
          <div className="field-grid"><Field label="Expiry date" placeholder="MM / YY" /><Field label="CVV" placeholder="123" /></div>
          <Field label="Name on card" placeholder="Alex Morgan" />
          <label className="save-card"><input type="checkbox" defaultChecked /><span>Save this card for next time</span></label>
        </section>
      )}
      <section className="payment-summary">
        <div><span>Order total</span><strong>$252.00</strong></div>
        <small><Icon name="shield" size={15} /> Your payment details are secure and encrypted.</small>
      </section>
      <div className="sticky-action plain"><Button onClick={() => go("confirmation")}>Pay $252.00 <Icon name="shield" size={17} /></Button></div>
    </main>
  );
}

function Confirmation({ go }: { go: (s: Screen) => void }) {
  return (
    <main className="screen confirmation-screen">
      <div className="confirmation-mark"><span><Icon name="check" size={36} /></span><i /><i /><i /></div>
      <span className="eyebrow">ORDER CONFIRMED</span>
      <div className="display-title">It’s on the way.</div>
      <p>Thanks, Alex. We’ve received your order and will send tracking updates to your inbox.</p>
      <section className="order-card">
        <div><span>ORDER NUMBER</span><strong>#SE-24189</strong></div>
        <div><span>ESTIMATED DELIVERY</span><strong>Friday, June 14</strong></div>
        <div className="order-thumbs"><img src={photos.shoe} alt="" /><img src={photos.tech} alt="" /><span>2 items</span></div>
        <p><span>Total paid</span><strong>$252.00</strong></p>
      </section>
      <Button onClick={() => go("homeA")}>Continue shopping</Button>
      <Button variant="soft" onClick={() => go("review")}>Open stakeholder review</Button>
    </main>
  );
}

function MiniHome({ option }: { option: "A" | "B" }) {
  return (
    <div className={`mini-home option-${option.toLowerCase()}`}>
      <div className="mini-top"><b>ShopEase.</b><span>●</span></div>
      <div className="mini-search" />
      {option === "A" ? (
        <><div className="mini-banner"><i /><span><b>Less noise.</b><small>Better choices.</small></span></div><div className="mini-pills"><i /><i /><i /><i /></div></>
      ) : (
        <><div className="mini-banner photo"><span><small>WEEKEND EDIT</small><b>Fresh looks.</b></span></div><div className="mini-cats"><i /><i /><i /><i /></div></>
      )}
      <div className="mini-label"><b>Featured</b><span>See all</span></div>
      <div className="mini-products"><i /><i /></div>
    </div>
  );
}

const criteria = [
  ["Visual Appeal", "Clean & refined", "Bold & engaging"],
  ["Ease of Navigation", "Highly intuitive", "Easy to discover"],
  ["Product Visibility", "Focused selection", "High visual impact"],
  ["Simplicity", "Excellent", "Moderate"],
  ["User Experience", "Calm & efficient", "Dynamic & inspiring"],
];

function Review({ go, setPreference }: { go: (s: Screen) => void; setPreference: (p: "A" | "B" | "Changes") => void }) {
  const choose = (value: "A" | "B" | "Changes") => { setPreference(value); go("feedback"); };
  return (
    <main className="screen review-screen">
      <Header title="Design review" eyebrow="STAKEHOLDER WORKSPACE" onBack={() => go("homeA")} />
      <section className="review-intro">
        <span>DECISION REQUIRED</span>
        <div className="review-title">Two directions.<br />One shared vision.</div>
        <p>Compare the alternatives against agreed criteria and help us resolve conflicting stakeholder opinions.</p>
      </section>
      <div className="process-strip">
        {["Opinions", "Alternatives", "Compare", "Feedback", "Changes", "Approval"].map((item, i) => <span key={item} className={i < 3 ? "done" : ""}><i>{i < 2 ? "✓" : i + 1}</i><small>{item}</small></span>)}
      </div>
      <div className="option-tabs"><span><i>A</i><b>Minimal UI</b></span><span><i>B</i><b>Visual & Promotional</b></span></div>
      <div className="comparison-previews"><MiniHome option="A" /><MiniHome option="B" /></div>
      <div className="comparison-table">
        <div className="table-head"><span>Evaluation criteria</span><b>Option A</b><b>Option B</b></div>
        {criteria.map((row) => <div key={row[0]}><strong>{row[0]}</strong><span>{row[1]}</span><span>{row[2]}</span></div>)}
      </div>
      <p className="review-note"><Icon name="profile" size={16} /> Your response will be added to the project decision log.</p>
      <div className="review-actions">
        <Button onClick={() => choose("A")}>Prefer Option A</Button>
        <Button variant="dark" onClick={() => choose("B")}>Prefer Option B</Button>
        <Button variant="soft" onClick={() => choose("Changes")}>Request changes</Button>
      </div>
    </main>
  );
}

function Rating({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return <div className="rating-row">{[1, 2, 3, 4, 5].map((n) => <button aria-label={`${n} stars`} type="button" onClick={() => onChange(n)} key={n}><Icon name="star" size={25} filled={n <= value} /></button>)}</div>;
}

function Feedback({
  go,
  preference,
  ratings,
  setRatings,
  comments,
  setComments,
}: {
  go: (s: Screen) => void;
  preference: string;
  ratings: Record<string, number>;
  setRatings: (r: Record<string, number>) => void;
  comments: string;
  setComments: (c: string) => void;
}) {
  return (
    <main className="screen feedback-screen">
      <Header title="Share feedback" eyebrow="DESIGN REVIEW · STEP 2 OF 3" onBack={() => go("review")} />
      <section className="feedback-hero"><span>Your selection</span><strong>{preference === "Changes" ? "Request changes" : `Option ${preference} — ${preference === "A" ? "Minimal UI" : "Visual & Promotional UI"}`}</strong></section>
      <p className="intro-copy">Rate the selected direction. Your responses help the team make an evidence-based decision.</p>
      <div className="rating-list">
        {["Visual appeal", "Ease of navigation", "Product visibility", "Simplicity", "Overall experience"].map((item) => (
          <div key={item}><span><strong>{item}</strong><small>{ratings[item]}/5</small></span><Rating value={ratings[item]} onChange={(n) => setRatings({ ...ratings, [item]: n })} /></div>
        ))}
      </div>
      <section className="selection-group">
        <strong>What matters most to you?</strong>
        <div>{["Fast navigation", "Strong visuals", "Clear pricing", "Fewer distractions"].map((item, i) => <label key={item}><input type="checkbox" defaultChecked={i < 2} /><span>{item}</span></label>)}</div>
      </section>
      <label className="comment-box"><span>Additional comments</span><textarea value={comments} onChange={(e) => setComments(e.target.value)} placeholder="Tell us what works, what doesn’t, or what should change..." /><small>{comments.length}/300</small></label>
      <Button onClick={() => go("summary")}>Submit feedback <span>→</span></Button>
    </main>
  );
}

function Summary({ go, preference, ratings, comments }: { go: (s: Screen) => void; preference: string; ratings: Record<string, number>; comments: string }) {
  const average = (Object.values(ratings).reduce((a, b) => a + b, 0) / Object.values(ratings).length).toFixed(1);
  return (
    <main className="screen summary-screen">
      <Header title="Feedback summary" eyebrow="DESIGN REVIEW · STEP 3 OF 3" onBack={() => go("feedback")} />
      <section className="summary-hero">
        <span><Icon name="check" size={24} /></span>
        <div><small>FEEDBACK RECORDED</small><strong>Direction aligned.</strong><p>Your response is ready for the final approval review.</p></div>
      </section>
      <section className="decision-card">
        <small>PREFERRED DIRECTION</small>
        <div><i>{preference}</i><span><strong>{preference === "A" ? "Minimal UI" : preference === "B" ? "Visual & Promotional UI" : "Refined Hybrid"}</strong><small>Selected by stakeholder</small></span><em><Icon name="check" size={16} /> Recorded</em></div>
      </section>
      <div className="summary-stats"><span><strong>{average}</strong><small>Average rating</small></span><span><strong>4/4</strong><small>Priorities captured</small></span></div>
      <section className="rating-summary">
        <strong>Rating overview</strong>
        {Object.entries(ratings).map(([name, value]) => <div key={name}><span>{name}</span><i><b style={{ width: `${value * 20}%` }} /></i><strong>{value}.0</strong></div>)}
      </section>
      <section className="comment-summary"><small>STAKEHOLDER COMMENT</small><p>“{comments || "Keep the simple navigation from Option A while adding one stronger promotional moment from Option B."}”</p></section>
      <section className="change-log"><strong>Recommended changes</strong><p><Icon name="check" size={16} /> Preserve simplified navigation architecture</p><p><Icon name="check" size={16} /> Increase promotional banner visibility</p><p><Icon name="check" size={16} /> Keep pricing and discounts easy to scan</p></section>
      <Button onClick={() => go("approval")}>Continue to final approval <span>→</span></Button>
    </main>
  );
}

function Approval({ go }: { go: (s: Screen) => void }) {
  const [status, setStatus] = useState<"pending" | "approved" | "changes">("pending");
  return (
    <main className="screen approval-screen">
      <Header title="Final design approval" eyebrow="SHOPEASE · RELEASE CANDIDATE" onBack={() => go("summary")} />
      <div className={`approval-seal ${status}`}>
        <span><Icon name={status === "approved" ? "check" : status === "changes" ? "arrow" : "shield"} size={33} /></span>
        <small>{status === "approved" ? "DESIGN APPROVED" : status === "changes" ? "REVISION REQUESTED" : "READY FOR DECISION"}</small>
        <div>{status === "approved" ? "Approved for build." : status === "changes" ? "Sent back for refinement." : "The final direction is ready."}</div>
        <p>{status === "approved" ? "Stakeholder approval has been recorded. The team can proceed to implementation." : "Review the agreed solution and confirm whether it is ready to move into development."}</p>
      </div>
      <section className="final-design-card">
        <div className="final-preview"><MiniHome option="A" /></div>
        <div className="final-copy"><span>FINAL DIRECTION · V2.0</span><strong>ShopEase Refined Minimal</strong><p>Minimal navigation and product clarity, enhanced with a focused promotional moment.</p><div><i>✓ Simplified navigation</i><i>✓ Stronger product imagery</i><i>✓ Clear pricing hierarchy</i></div></div>
      </section>
      <div className="approval-flow">
        {["Conflicting opinions", "Alternative designs", "Comparison", "Feedback", "Changes applied", "Final approval"].map((item, i) => <span key={item}><i>{i < 5 || status === "approved" ? "✓" : "6"}</i><small>{item}</small></span>)}
      </div>
      <section className="decision-log">
        <strong>Decision record</strong>
        <p><span>Stakeholder</span><b>Alex Morgan</b></p>
        <p><span>Review date</span><b>June 11, 2025</b></p>
        <p><span>Prototype version</span><b>ShopEase v2.0</b></p>
      </section>
      {status === "pending" ? (
        <div className="approval-actions"><Button onClick={() => setStatus("approved")}><Icon name="check" /> Approve design</Button><Button variant="soft" onClick={() => setStatus("changes")}>Request changes</Button></div>
      ) : (
        <Button variant={status === "approved" ? "primary" : "dark"} onClick={() => status === "approved" ? go("homeA") : go("feedback")}>{status === "approved" ? "Return to prototype" : "Add revision notes"} <span>→</span></Button>
      )}
    </main>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const [history, setHistory] = useState<Screen[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([1, 2]);
  const [quantity, setQuantity] = useState(1);
  const [preference, setPreference] = useState<"A" | "B" | "Changes">("A");
  const [ratings, setRatings] = useState<Record<string, number>>({
    "Visual appeal": 4,
    "Ease of navigation": 5,
    "Product visibility": 4,
    Simplicity: 5,
    "Overall experience": 4,
  });
  const [comments, setComments] = useState("Keep the simple navigation from Option A, but add one stronger promotional moment from Option B.");

  const go = (next: Screen) => {
    setHistory((prev) => [...prev.slice(-8), screen]);
    setScreen(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const toggleLike = (id: number) => setWishlist((list) => list.includes(id) ? list.filter((item) => item !== id) : [...list, id]);

  const current = useMemo(() => {
    const common = { go };
    switch (screen) {
      case "welcome": return <Welcome {...common} />;
      case "homeA": return <HomeA {...common} wishlist={wishlist} toggleLike={toggleLike} />;
      case "homeB": return <HomeB {...common} wishlist={wishlist} toggleLike={toggleLike} />;
      case "categories": return <Categories {...common} />;
      case "listing": return <Listing {...common} wishlist={wishlist} toggleLike={toggleLike} />;
      case "details": return <Details {...common} liked={wishlist.includes(1)} toggleLike={() => toggleLike(1)} />;
      case "wishlist": return <Wishlist {...common} wishlist={wishlist} toggleLike={toggleLike} />;
      case "cart": return <Cart {...common} quantity={quantity} setQuantity={setQuantity} />;
      case "checkout": return <Checkout {...common} />;
      case "payment": return <Payment {...common} />;
      case "confirmation": return <Confirmation {...common} />;
      case "review": return <Review {...common} setPreference={setPreference} />;
      case "feedback": return <Feedback {...common} preference={preference} ratings={ratings} setRatings={setRatings} comments={comments} setComments={setComments} />;
      case "summary": return <Summary {...common} preference={preference} ratings={ratings} comments={comments} />;
      case "approval": return <Approval {...common} />;
    }
  }, [screen, wishlist, quantity, preference, ratings, comments]);

  return (
    <div className="app-shell">
      <div className="desktop-context">
        <div className="context-brand"><span>S</span><div><strong>ShopEase</strong><small>Interactive prototype</small></div></div>
        <div className="context-copy"><span>SOFTWARE ENGINEERING PRACTICAL</span><div>From disagreement<br />to design approval.</div><p>A high-fidelity commerce prototype built to align stakeholders through alternatives, structured feedback, and a documented decision.</p></div>
        <div className="context-flow">{["Conflicting opinions", "Alternative designs", "Comparison", "Feedback", "Changes", "Final approval"].map((item, i) => <span key={item} className={screen === "review" && i < 3 ? "active" : ""}><i>{i + 1}</i>{item}</span>)}</div>
        <button type="button" className="context-review" onClick={() => go("review")}>Open stakeholder workspace <span>→</span></button>
      </div>
      <div className="phone-wrap">
        <div className="phone-status"><span>9:41</span><div><i>●●●</i><b>▰</b></div></div>
        {current}
        {screen === "review" && <button type="button" className="preview-switch" onClick={() => go("homeB")}>Preview Option B</button>}
        {screen === "homeA" && history.includes("review") && <button type="button" className="preview-switch" onClick={() => go("homeB")}>Switch to Option B</button>}
        {screen === "homeB" && <button type="button" className="preview-switch" onClick={() => go("review")}>Back to comparison</button>}
      </div>
    </div>
  );
}
